// ============================================================
//  COMPONENTE — src/components/Contact/ContactSection.jsx
//  Seção de contato com informações + formulário.
//  Não recebe props — é autônomo.
// ============================================================

import { useState } from "react";
import { CONTACT_INFO, SOCIALS } from "../../data/index";

export default function ContactSection() {
  // Estado do formulário
  const [form, setForm] = useState({
    name: "", email: "", subject: "", budget: "", message: "",
  });

  // Estado de feedback (ok = sucesso, err = erro)
  const [status,  setStatus]  = useState({ type: "", msg: "" });
  const [loading, setLoading] = useState(false);

  // Atualiza um campo do formulário pelo name do input
  const handleChange = (e) =>
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  // Submissão do formulário
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validação básica
    if (!form.name || !form.email || !form.message) {
      setStatus({ type: "err", msg: "⚠ Preencha os campos obrigatórios." });
      return;
    }
    if (!/\S+@\S+\.\S+/.test(form.email)) {
      setStatus({ type: "err", msg: "⚠ Email inválido." });
      return;
    }

    // Simula envio (substitua pelo fetch real quando tiver backend)
    setLoading(true);
    setStatus({ type: "", msg: "" });
    await new Promise((r) => setTimeout(r, 1500));
    setLoading(false);
    setStatus({ type: "ok", msg: "✓ Mensagem enviada! Respondo em breve." });
    setForm({ name: "", email: "", subject: "", budget: "", message: "" });

    // Limpa mensagem de sucesso após 5 segundos
    setTimeout(() => setStatus({ type: "", msg: "" }), 5000);
  };

  return (
    <section className="contact" id="contato">
      <div className="ccontainer">
        <div className="cg">

          {/* ── COLUNA ESQUERDA: informações ── */}
          <div>
            <span className="sn">03 — Contato</span>
            <h2 className="st">Vamos construir <em>algo juntos</em></h2>
            <p className="cdesc">
              Tem um projeto interessante ou uma oportunidade que quer discutir?
              Estou sempre aberto a conversar sobre novas ideias,{" "}
              <strong>colaborações</strong> ou simplesmente bater um papo sobre tecnologia.
            </p>

            {/* Itens de contato (email, localização, tempo de resposta) */}
            <div className="cinfo">
              {CONTACT_INFO.map(({ icon, label, val, href }) =>
                href ? (
                  <a key={label} href={href} className="ci-item">
                    <span className="ci-icon">{icon}</span>
                    <div>
                      <span className="ci-label">{label}</span>
                      <span className="ci-val">{val}</span>
                    </div>
                  </a>
                ) : (
                  <div key={label} className="ci-item">
                    <span className="ci-icon">{icon}</span>
                    <div>
                      <span className="ci-label">{label}</span>
                      <span className="ci-val">{val}</span>
                    </div>
                  </div>
                )
              )}
            </div>

            {/* Botões de redes sociais */}
            <div className="socials">
              {SOCIALS.map(({ code, title }) => (
                <a key={code} href="#" className="soc" title={title}
                   onClick={(e) => e.preventDefault()}>
                  {code}
                </a>
              ))}
            </div>

            {/* Badge "disponível" */}
            <div className="avail">
              <span className="av-dot" />
              <div>
                <div className="av-title">Disponível para projetos</div>
                <div className="av-sub">Freelance · Full-time · Colaboração</div>
              </div>
              <span className="av-badge">Open to work</span>
            </div>
          </div>

          {/* ── COLUNA DIREITA: formulário ── */}
          <form className="cform" onSubmit={handleSubmit} noValidate>

            {/* Nome + Email lado a lado */}
            <div className="fr2">
              <div className="fg">
                <label className="fl" htmlFor="name">Nome <span>*</span></label>
                <input
                  id="name" name="name" className="fi" type="text"
                  placeholder="Seu nome" value={form.name}
                  onChange={handleChange} required autoComplete="name"
                />
              </div>
              <div className="fg">
                <label className="fl" htmlFor="email">Email <span>*</span></label>
                <input
                  id="email" name="email" className="fi" type="email"
                  placeholder="seu@email.com" value={form.email}
                  onChange={handleChange} required autoComplete="email"
                />
              </div>
            </div>

            {/* Assunto */}
            <div className="fg">
              <label className="fl" htmlFor="subject">Assunto</label>
              <input
                id="subject" name="subject" className="fi" type="text"
                placeholder="Sobre o que é?" value={form.subject}
                onChange={handleChange}
              />
            </div>

            {/* Orçamento (select) */}
            <div className="fg">
              <label className="fl" htmlFor="budget">Orçamento estimado</label>
              <select
                id="budget" name="budget" className="fi fsel"
                value={form.budget} onChange={handleChange}
              >
                <option value="" disabled>Selecione uma faixa</option>
                <option>Menos de R$1.000</option>
                <option>R$1.000 – R$5.000</option>
                <option>R$5.000 – R$15.000</option>
                <option>Acima de R$15.000</option>
                <option>A combinar</option>
              </select>
            </div>

            {/* Mensagem */}
            <div className="fg">
              <label className="fl" htmlFor="message">Mensagem <span>*</span></label>
              <textarea
                id="message" name="message" className="ft" rows={5}
                placeholder="Conte um pouco sobre seu projeto ou ideia..."
                value={form.message} onChange={handleChange} required
              />
            </div>

            {/* Botão de envio + feedback */}
            <div className="fsr">
              <button type="submit" className="cbtn" disabled={loading}>
                {loading ? (
                  <><span className="spin" />&nbsp;Enviando...</>
                ) : (
                  <>Enviar mensagem <span className="cba">→</span></>
                )}
              </button>
              {status.msg && (
                <p className={`fstatus ${status.type}`} role="status" aria-live="polite">
                  {status.msg}
                </p>
              )}
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
